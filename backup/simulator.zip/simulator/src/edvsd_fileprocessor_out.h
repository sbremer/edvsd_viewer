#ifndef EDVSD_FILEPROCESSOR_OUT_H
#define EDVSD_FILEPROCESSOR_OUT_H

#include <QFile>
#include "edvsd.h"

class EDVSD_Fileprocessor_Out
{
public:
	EDVSD_Fileprocessor_Out();
	~EDVSD_Fileprocessor_Out();
	bool open(QString p_filename);
	void write(EDVS_Event p_event);
	void write(EDVS_Header p_header);
	void save();

private:
	QFile* m_file;
	bool m_fileopen;
};

#endif // EDVSD_FILEPROCESSOR_OUT_H
