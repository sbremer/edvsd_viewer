#include "edvsd_simulator.h"

#include <iostream>
using namespace std;

EDVSD_Simulator::EDVSD_Simulator()
	:m_list()
{
	//Currently static Header
	m_header.version = 1;
	m_header.x_resolution = 128;
	m_header.y_resolution = 128;
	m_header.timestamp_resolution = EDVS_Timestamp_Resolution_32bit;
}

void EDVSD_Simulator::simulate(/*  parameters  */)
{
	//Seed qrand
	qsrand(QTime::currentTime().msec());

	//Settings
	int time_deviation = 3000; //in us, should at least be 100
	double noise_level = 0.02;

	//Frame buffers
	qint8 frame[128*128];
	qint8 frame_old[128*128];
	qint8 frame_diff[128*128];

	//Initiallize buffers
	for(int a = 0; a < 128*128; a++){
		frame[a] = frame_old[a] = frame_diff[a] = 0;
	}

	//Sample for every 100 us
	int time_length = 50000;
	for(int t = 0; t < time_length; t++){ //10000 ts/sec

		cout << "Progress: " << 100.0 * t / time_length << "%      \r";

		//Draw objects
		for(QList<ElipseObject>::iterator iter = m_objects.begin(); iter != m_objects.end(); iter++){
			int size_max = qMax(iter->w, iter->h);

			int x_start = qMax(0, (int)(iter->x - size_max));
			int x_end = qMin(128, (int)(iter->x + size_max));

			int y_start = qMax(0, (int)(iter->y - size_max));
			int y_end = qMin(128, (int)(iter->y + size_max));

			double sin = qSin(iter->angle);
			double cos = qCos(iter->angle);

			//Iterate through maximal possible extend in rectangular form for easy iteration
			for(int x = x_start; x < x_end; x++){
				for(int y = y_start; y < y_end; y++){

					double dx = x - iter->x;
					double dy = y - iter->y;

					double dist = qSqrt( (cos*dx - sin*dy) * (cos*dx - sin*dy) / iter->w / iter->w
										 + (sin*dx + cos*dy) * (sin*dx + cos*dy) / iter->h / iter->h );

					if(dist <= 1.0){
						frame[x + y*128] = 1;
					}
				}
			}
		}

		//Modify object properties, spawn/remove objects
		if(t % 500 == 0){
			ElipseObject obj;
			obj.x = -10;
			obj.y = 20;
			obj.w = 5;
			obj.h = 1.5;

			if(t > 15000){
				obj.angle = M_PI_2;
				obj.y = 38;
			}
			else{
				obj.angle = 0;
			}

			m_objects.append(obj);
		}

		for(QList<ElipseObject>::iterator iter = m_objects.begin(); iter != m_objects.end(); iter++){
			iter->x += 40.0 / 1000;
			iter->y += iter->x / 1000;
			iter->angle += M_PI_2 / 4 / 1000;
		}

		//Calculate difference
		for(int x = 0; x < 128; x++){
			for(int y = 0; y < 128; y++){

				int a = x + y*128;

				frame_diff[a] = frame[a] - frame_old[a];

				if(frame_diff[a] == 1){
					//Queue "on" event
					EDVS_Event event;
					event.x = x;
					event.y = y;
					event.p = 1;
					event.t = t * 100 + (qrand() %  time_deviation);
					m_list.append(event);
				}

				else if(frame_diff[a] == -1){
					//Queue "off" event
					EDVS_Event event;
					event.x = x;
					event.y = y;
					event.p = 0;
					event.t = t * 100 + (qrand() %  time_deviation);
					m_list.append(event);
				}
			}
		}

		//Copy frame to frame old, clear frame
		for(int a = 0; a < 128*128; a++){
			frame_old[a] = frame[a];
			frame[a] = 0;
		}
	}

	cout << "Post Simulation Steps...\r";

	//Find min/max timestamp of generated events
	quint32 min = 0xFFFFFFFF, max = 0;
	for(QList<EDVS_Event>::iterator iter = m_list.begin(); iter != m_list.end(); iter++){
		if(iter->t < min){
			min = iter->t;
		}
		else if(iter->t > max){
			max = iter->t;
		}
	}

	//Shift all timestamps so that startvalue is 0
	if(min != 0){
		for(QList<EDVS_Event>::iterator iter = m_list.begin(); iter != m_list.end(); iter++){
			iter->t -= min;
		}
	}

	min = 0;
	max -= min;

	cout << "Adding noise...\r";

	//Generate noise
	int noise_events = noise_level * m_list.size();
	for(int a = 0; a < noise_events; a++){
		EDVS_Event event;
		event.x = qrand() % 128;
		event.y = qrand() % 128;
		event.p = qrand() % 2;
		event.t = qrand() % max;
		m_list.append(event);
	}

	cout << "Sorting...\r";

	//Sort events by time
	qSort(m_list.begin(), m_list.end());

}

EDVS_Header EDVSD_Simulator::getHeader()
{
	return m_header;
}

EDVS_Event EDVSD_Simulator::getEvent()
{
	EDVS_Event event = m_list.front();
	m_list.pop_front();
	return event;
}

int EDVSD_Simulator::getLength()
{
	return m_list.length();
}
