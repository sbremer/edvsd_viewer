#ifndef EDVSD_SIMULATOR_H
#define EDVSD_SIMULATOR_H

#include "edvsd.h"
#include <QList>
#include <QTime>
#include <qmath.h>

struct ElipseObject{
	double x,y;
	double w,h;
	double angle;
};

class EDVSD_Simulator
{
public:
	EDVSD_Simulator();

	void simulate(/*  parameters  */);

	EDVS_Header getHeader();
	EDVS_Event getEvent();
	int getLength();

private:
	EDVS_Header m_header;
	QList<EDVS_Event> m_list;

	QList<ElipseObject> m_objects;
};

#endif // EDVSD_SIMULATOR_H
