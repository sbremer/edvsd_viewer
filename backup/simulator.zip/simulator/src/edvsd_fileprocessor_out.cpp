#include "edvsd_fileprocessor_out.h"

EDVSD_Fileprocessor_Out::EDVSD_Fileprocessor_Out()
	:m_file(NULL), m_fileopen(false)
{

}

EDVSD_Fileprocessor_Out::~EDVSD_Fileprocessor_Out()
{
	if(m_file != NULL){
		delete m_file;
	}
}

bool EDVSD_Fileprocessor_Out::open(QString p_filename)
{
	if(p_filename.length()==0)
		return false;

	m_file = new QFile(p_filename);

	if(!m_file->open(QIODevice::WriteOnly))
		return false;

	m_fileopen = true;
	return true;
}

void EDVSD_Fileprocessor_Out::write(EDVS_Event p_event)
{
	if(m_fileopen){
		m_file->write((char*)(&p_event), sizeof(EDVS_Event));
	}
}

void EDVSD_Fileprocessor_Out::write(EDVS_Header p_header)
{
	if(m_fileopen){
		m_file->write((char*)(&p_header), sizeof(EDVS_Header));
	}
}

void EDVSD_Fileprocessor_Out::save()
{
	if(m_fileopen){
		m_file->flush();
		m_file->close();
	}
}
