#include <iostream>

#include "edvsd.h"

#include "edvsd_simulator.h"
#include "edvsd_fileprocessor_out.h"

using namespace std;

int main()
{
	EDVSD_Simulator simulator = EDVSD_Simulator();

	simulator.simulate();

	EDVSD_Fileprocessor_Out fileprocessor = EDVSD_Fileprocessor_Out();

	QString filename = "simulatoroutput.dvsd";

	if(!fileprocessor.open(filename)){
		cout << "Error occured!" << endl;
		return 1;
	}

	int filesize = sizeof(EDVS_Header) + simulator.getLength() * sizeof(EDVS_Event);

	fileprocessor.write(simulator.getHeader());

	while(simulator.getLength()){
		fileprocessor.write(simulator.getEvent());
	}

	fileprocessor.save();

	cout << filesize << " Bytes written to " << filename.toLocal8Bit().data() << "!" << endl;

	return 0;
}

